# Entrega — Nexo Console Lab

## Stack
- Astro 7.3.x
- TypeScript (strict)
- Tailwind CSS 4 via `@tailwindcss/vite`
- CSS variables para design tokens
- JavaScript nativo apenas nas interações necessárias
- Astro Content Collections para o blog
- `@astrojs/sitemap` para sitemap

## Rotas implementadas
- `/`
- `/servicos`
- `/servicos/manutencao-consoles`
- `/servicos/manutencao-controles`
- `/servicos/limpeza-preventiva`
- `/servicos/reparo-hdmi`
- `/servicos/drift-controle`
- `/servicos/superaquecimento`
- `/consoles`
- `/consoles/playstation`
- `/consoles/xbox`
- `/consoles/nintendo-switch`
- `/sobre`
- `/como-funciona`
- `/orcamento`
- `/faq`
- `/blog`
- 6 artigos iniciais
- `/contato`
- `/politica-de-privacidade`
- `/404`

## Funcionalidades
- Menu responsivo animado
- Triagem/diagnóstico visual em 3 etapas
- Formulário de orçamento em 4 etapas
- Geração de mensagem pronta para WhatsApp
- Comparador antes/depois
- Contadores animados
- FAQ acessível com `details/summary`
- Blog com Content Collections
- SEO por página + Open Graph + Twitter Cards
- JSON-LD de LocalBusiness, Service, FAQPage, BreadcrumbList e Article onde aplicável
- Sitemap, robots.txt e canonical
- Suporte a `prefers-reduced-motion`
- Foco visível e link “pular para conteúdo”
- Imagens SVG locais e leves

## Antes de publicar
Edite `src/config/siteConfig.ts` e substitua todos os dados demonstrativos por dados reais. Ajuste também o domínio em `astro.config.mjs` e `public/robots.txt`.

Os números de reparos/avaliações são demonstrativos e estão explicitamente marcados no site até serem substituídos por números reais.
