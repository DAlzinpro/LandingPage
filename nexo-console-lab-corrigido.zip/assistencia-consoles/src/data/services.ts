export type Service = {
  slug: string;
  title: string;
  eyebrow: string;
  summary: string;
  problem: string;
  symptoms: string[];
  causes: string[];
  diagnosis: string[];
  repair: string[];
  devices: string[];
  faq: { q: string; a: string }[];
};

export const services: Service[] = [
  {
    slug: 'manutencao-consoles',
    title: 'Manutenção de consoles',
    eyebrow: 'DIAG / CONSOLE',
    summary: 'Diagnóstico e reparo de PlayStation, Xbox e Nintendo com análise de alimentação, vídeo, refrigeração e placa.',
    problem: 'Travamentos, desligamentos, falha de vídeo ou ruído excessivo podem ter causas diferentes. O reparo começa identificando o defeito real antes de trocar peças.',
    symptoms: ['Desliga sozinho', 'Não liga', 'Sem imagem', 'Muito barulho', 'Travamentos', 'Falha de leitura ou carregamento'],
    causes: ['Acúmulo de poeira', 'Falha de alimentação', 'Conector danificado', 'Problemas térmicos', 'Componentes de placa', 'Desgaste de armazenamento ou leitor'],
    diagnosis: ['Inspeção visual e de conectores', 'Teste de fontes e tensões', 'Avaliação térmica', 'Teste de vídeo e portas', 'Testes funcionais antes do orçamento'],
    repair: ['Correção do defeito identificado', 'Limpeza técnica quando necessária', 'Substituição pontual de peças', 'Testes de estabilidade e temperatura', 'Registro do serviço executado'],
    devices: ['PS4 / PS4 Pro', 'PS5 / PS5 Slim', 'Xbox One', 'Xbox Series S/X', 'Nintendo Switch / OLED / Lite'],
    faq: [
      { q: 'Vocês trocam peças sem avisar?', a: 'Não. O orçamento é apresentado antes do reparo e a execução depende da autorização do cliente.' },
      { q: 'Todo console que não liga é fonte?', a: 'Não. Sintomas iguais podem ter causas diferentes, por isso o diagnóstico vem antes da troca de peças.' },
    ],
  },
  {
    slug: 'manutencao-controles',
    title: 'Manutenção de controles',
    eyebrow: 'INPUT / REPAIR',
    summary: 'Reparo de DualSense, DualShock, controles Xbox e Joy-Con com foco em analógicos, botões, bateria e carregamento.',
    problem: 'Um controle pode falhar por desgaste mecânico, oxidação, impacto ou defeito eletrônico. A análise separa o que é desgaste normal do que exige reparo de placa.',
    symptoms: ['Analógico puxando sozinho', 'Botão não responde', 'Não carrega', 'Desconecta', 'Gatilho com falha', 'Bateria dura pouco'],
    causes: ['Desgaste de potenciômetro', 'Solda danificada', 'Membranas gastas', 'Conector USB com folga', 'Bateria degradada', 'Oxidação'],
    diagnosis: ['Teste de todos os eixos e botões', 'Leitura de entrada no software de teste', 'Inspeção do conector', 'Análise de bateria e carga', 'Verificação de placa'],
    repair: ['Troca de analógicos ou módulos quando necessário', 'Correção de solda', 'Troca de membranas/botões', 'Reparo de carga', 'Calibração e teste final'],
    devices: ['DualSense', 'DualShock 4', 'Controle Xbox One', 'Controle Xbox Series', 'Joy-Con', 'Pro Controller'],
    faq: [
      { q: 'Drift sempre exige trocar o analógico?', a: 'Nem sempre. O diagnóstico verifica desgaste, sujeira, calibração e condição do módulo antes da decisão.' },
      { q: 'O controle é testado depois?', a: 'Sim. Eixos, botões, gatilhos, conexão e carregamento são testados antes da entrega.' },
    ],
  },
  {
    slug: 'limpeza-preventiva',
    title: 'Limpeza preventiva',
    eyebrow: 'THERMAL / CARE',
    summary: 'Limpeza interna focada em fluxo de ar, dissipação térmica e conservação dos componentes.',
    problem: 'Poeira acumulada aumenta ruído, eleva temperatura e dificulta a troca de calor. A prevenção reduz esforço do sistema de refrigeração.',
    symptoms: ['Ventoinha muito alta', 'Console quente', 'Poeira visível', 'Cheiro de aquecimento', 'Tempo longo sem manutenção'],
    causes: ['Ambiente com poeira', 'Uso contínuo', 'Entradas de ar obstruídas', 'Pasta térmica envelhecida', 'Acúmulo em dissipadores'],
    diagnosis: ['Inspeção das entradas de ar', 'Leitura de temperatura quando aplicável', 'Análise do dissipador', 'Verificação de pasta e pads térmicos'],
    repair: ['Desmontagem técnica', 'Remoção controlada de poeira', 'Limpeza de ventoinha e dissipador', 'Substituição térmica quando indicada', 'Teste de ruído e temperatura'],
    devices: ['PS4 / PS5', 'Xbox One / Series', 'Nintendo Switch', 'Notebooks gamer e acessórios sob consulta'],
    faq: [
      { q: 'Precisa trocar pasta térmica em toda limpeza?', a: 'Não automaticamente. A necessidade depende do modelo, condição e histórico do equipamento.' },
      { q: 'Limpeza resolve qualquer superaquecimento?', a: 'Não. Ela resolve problemas de sujeira e fluxo de ar, mas falhas de sensor, ventoinha ou placa exigem outro diagnóstico.' },
    ],
  },
  {
    slug: 'reparo-hdmi',
    title: 'Reparo de HDMI',
    eyebrow: 'VIDEO / PORT',
    summary: 'Correção de portas HDMI danificadas e análise do circuito de vídeo quando o console liga, mas não apresenta imagem.',
    problem: 'Sem imagem pode ser porta quebrada, trilha danificada ou falha em componentes do circuito de vídeo. Trocar o conector sem testar o restante pode não resolver.',
    symptoms: ['Sem sinal', 'Imagem piscando', 'Conector frouxo', 'Pinos tortos', 'Imagem some ao mexer no cabo'],
    causes: ['Impacto no cabo', 'Cabo forçado', 'Soldas rompidas', 'Trilhas arrancadas', 'Falha em CI ou proteção de vídeo'],
    diagnosis: ['Inspeção microscópica', 'Teste do conector', 'Continuidade de linhas', 'Análise de componentes de proteção', 'Teste com cabos e telas diferentes'],
    repair: ['Remoção do conector danificado', 'Reconstrução de trilhas quando possível', 'Instalação e alinhamento do novo conector', 'Revisão do circuito', 'Teste de resolução e estabilidade'],
    devices: ['PS4', 'PS5', 'Xbox One', 'Xbox Series S', 'Xbox Series X', 'Nintendo Switch Dock sob consulta'],
    faq: [
      { q: 'Dá para saber o preço só pela foto?', a: 'A foto ajuda na triagem, mas o valor depende da condição da porta, trilhas e circuito ao redor.' },
      { q: 'Vocês testam em 4K?', a: 'O teste final considera os modos compatíveis com cada equipamento e a estabilidade do sinal.' },
    ],
  },
  {
    slug: 'drift-controle',
    title: 'Correção de drift',
    eyebrow: 'STICK / CAL',
    summary: 'Diagnóstico de analógicos que registram movimento sem toque, com reparo e calibração do controle.',
    problem: 'Drift é o movimento involuntário do eixo analógico. Ele pode aparecer por desgaste interno, sujeira, folga mecânica ou falha no circuito de leitura.',
    symptoms: ['Personagem anda sozinho', 'Mira puxa para um lado', 'Eixo não centraliza', 'Movimento irregular'],
    causes: ['Potenciômetro desgastado', 'Módulo analógico gasto', 'Sujeira interna', 'Dano mecânico', 'Solda ou trilha afetada'],
    diagnosis: ['Leitura dos eixos em software', 'Teste de deadzone', 'Inspeção do módulo', 'Verificação mecânica e elétrica'],
    repair: ['Substituição do componente necessário', 'Retrabalho de solda quando preciso', 'Calibração', 'Teste de centralização e amplitude'],
    devices: ['DualSense', 'DualShock 4', 'Xbox One/Series', 'Joy-Con', 'Pro Controller'],
    faq: [
      { q: 'Aumentar a deadzone resolve?', a: 'Pode esconder um drift leve em alguns jogos, mas não corrige desgaste físico do componente.' },
      { q: 'O analógico fica calibrado?', a: 'O serviço inclui teste de centro, extremos e resposta após o reparo.' },
    ],
  },
  {
    slug: 'superaquecimento',
    title: 'Superaquecimento',
    eyebrow: 'TEMP / CONTROL',
    summary: 'Análise de refrigeração, fluxo de ar, interface térmica, ventoinha e sensores para consoles que aquecem além do normal.',
    problem: 'A temperatura alta é um sintoma, não um diagnóstico. O objetivo é descobrir se a causa está em sujeira, dissipação, ventoinha, sensor ou placa.',
    symptoms: ['Aviso de temperatura', 'Desliga em jogos', 'Ventoinha acelera demais', 'Carcaça muito quente', 'Queda de desempenho'],
    causes: ['Dissipador obstruído', 'Pasta térmica degradada', 'Ventoinha com falha', 'Contato térmico ruim', 'Sensor ou circuito com defeito'],
    diagnosis: ['Inspeção do sistema térmico', 'Teste de ventoinha', 'Avaliação de dissipador', 'Medição térmica', 'Teste sob carga controlada'],
    repair: ['Limpeza do sistema', 'Correção de contato térmico', 'Troca de pasta/pads quando indicado', 'Substituição de ventoinha quando necessário', 'Teste prolongado de estabilidade'],
    devices: ['PS4 / PS5', 'Xbox One / Series', 'Nintendo Switch'],
    faq: [
      { q: 'Trocar pasta térmica sempre resolve?', a: 'Não. Se a causa for ventoinha, dissipador, sensor ou placa, a pasta térmica sozinha não resolve.' },
      { q: 'Vocês testam jogando?', a: 'O equipamento passa por teste de carga e estabilidade apropriado ao defeito e ao modelo.' },
    ],
  },
];
