export const testimonials = [
  { name: 'Marcos A.', model: 'PlayStation 5', rating: 5, text: 'Explicaram o que seria testado antes de mexer no console. O problema era no HDMI e ficou resolvido sem enrolação.' },
  { name: 'Bruna M.', model: 'DualSense', rating: 5, text: 'O controle estava puxando a mira sozinho. Fizeram o reparo, testaram comigo e ficou centralizado de novo.' },
  { name: 'Rafael C.', model: 'Xbox Series S', rating: 5, text: 'Gostei porque passaram o diagnóstico e o valor antes do serviço. Atendimento simples e bem explicado.' },
];
