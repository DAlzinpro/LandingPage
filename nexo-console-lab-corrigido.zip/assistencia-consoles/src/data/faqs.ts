export const faqs = [
  { q: 'Vocês fazem orçamento pelo WhatsApp?', a: 'Sim. O WhatsApp serve para triagem inicial e coleta de informações. O valor final depende do diagnóstico quando o defeito não pode ser confirmado à distância.' },
  { q: 'Quanto tempo leva o reparo?', a: 'Depende do defeito, disponibilidade de peças e fila técnica. Depois do diagnóstico, informamos a previsão antes de seguir.' },
  { q: 'Vocês consertam console que outra assistência já abriu?', a: 'Sim, desde que seja possível avaliar o estado atual. Avise no contato se o aparelho já passou por tentativa de reparo.' },
  { q: 'Posso mandar foto ou vídeo do problema?', a: 'Pode. Fotos e vídeos ajudam a triagem, principalmente em conectores quebrados, danos físicos e sintomas visíveis.' },
  { q: 'Existe garantia do serviço?', a: 'A garantia deve ser configurada de acordo com a política real da empresa. O projeto deixa esse conteúdo centralizado para você ajustar antes de publicar.' },
  { q: 'Vocês vendem peças?', a: 'O foco do site é manutenção. Venda avulsa de peças pode ser oferecida sob consulta se fizer parte da operação da assistência.' },
];
