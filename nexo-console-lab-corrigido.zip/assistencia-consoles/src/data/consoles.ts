export type ConsoleFamily = {
  slug: string;
  name: string;
  intro: string;
  models: string[];
  commonIssues: { title: string; service: string; text: string }[];
};

export const consoleFamilies: ConsoleFamily[] = [
  {
    slug: 'playstation',
    name: 'PlayStation',
    intro: 'Atendimento para gerações recentes da linha PlayStation e seus controles, com diagnóstico separado para alimentação, vídeo, refrigeração e entrada de comandos.',
    models: ['PS5', 'PS5 Slim', 'PS4 Pro', 'PS4 Slim', 'PS4 Fat', 'DualSense', 'DualShock 4'],
    commonIssues: [
      { title: 'Sem imagem', service: 'reparo-hdmi', text: 'Porta HDMI, proteção de vídeo e circuito de saída são analisados antes da troca de peças.' },
      { title: 'Desliga em jogos', service: 'superaquecimento', text: 'Temperatura, alimentação e estabilidade são testadas para separar falha térmica de falha elétrica.' },
      { title: 'DualSense com drift', service: 'drift-controle', text: 'O eixo é medido, o módulo é inspecionado e o reparo termina com calibração e teste.' },
    ],
  },
  {
    slug: 'xbox',
    name: 'Xbox',
    intro: 'Manutenção para Xbox One e Series com foco em vídeo, alimentação, armazenamento, refrigeração e controles.',
    models: ['Xbox Series X', 'Xbox Series S', 'Xbox One X', 'Xbox One S', 'Xbox One', 'Controle Xbox Series', 'Controle Xbox One'],
    commonIssues: [
      { title: 'Liga e não dá vídeo', service: 'reparo-hdmi', text: 'A porta e o circuito de vídeo são verificados em conjunto.' },
      { title: 'Aquecimento e ruído', service: 'limpeza-preventiva', text: 'Fluxo de ar, dissipador e ventoinha são avaliados para recuperar a refrigeração correta.' },
      { title: 'Analógico puxando', service: 'drift-controle', text: 'Teste dos eixos identifica desgaste e necessidade de reparo ou substituição do módulo.' },
    ],
  },
  {
    slug: 'nintendo-switch',
    name: 'Nintendo Switch',
    intro: 'Atendimento para Switch, OLED e Lite, incluindo Joy-Con, carga, conectores, refrigeração e falhas de vídeo.',
    models: ['Nintendo Switch', 'Switch OLED', 'Switch Lite', 'Joy-Con', 'Pro Controller', 'Dock'],
    commonIssues: [
      { title: 'Joy-Con com drift', service: 'drift-controle', text: 'O analógico é medido e testado antes e depois do reparo.' },
      { title: 'Não carrega', service: 'manutencao-consoles', text: 'Conector, linha de alimentação e componentes de carga são analisados.' },
      { title: 'Aquecendo demais', service: 'superaquecimento', text: 'Ventoinha, dissipador e interface térmica são revisados com cuidado.' },
    ],
  },
];
