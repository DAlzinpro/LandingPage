export const siteConfig = {
  businessName: 'Nexo Console Lab',
  shortName: 'Nexo',
  legalName: 'Nexo Console Lab Assistência Técnica',
  description:
    'Assistência técnica especializada em consoles e controles, com diagnóstico claro, reparo cuidadoso e testes antes da entrega.',
  phone: '(00) 00000-0000',
  whatsapp: '5500000000000',
  email: 'contato@exemplo.com.br',
  address: 'Endereço da assistência',
  neighborhood: 'Seu bairro',
  city: 'Sua cidade',
  state: 'UF',
  postalCode: '00000-000',
  country: 'BR',
  openingHours: [
    'Segunda a sexta: 09:00–18:00',
    'Sábado: 09:00–13:00',
  ],
  socialLinks: {
    instagram: '#',
    facebook: '#',
  },
  metrics: {
    consoles: 1200,
    controllers: 1850,
    years: 7,
    reviews: 386,
  },
  seo: {
    titleSuffix: ' | Nexo Console Lab',
    locale: 'pt_BR',
    twitterCard: 'summary_large_image',
  },
};

export const whatsappUrl = (message = 'Olá! Gostaria de solicitar um orçamento.') =>
  `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(message)}`;
