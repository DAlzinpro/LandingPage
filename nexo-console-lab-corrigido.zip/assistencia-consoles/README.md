# Nexo Console Lab

Website completo em Astro 7 + Tailwind CSS 4 para assistência técnica de consoles e controles.

## Rodar localmente

```bash
npm install
npm run dev
```

Build de produção:

```bash
npm run build
npm run preview
```

## Dados que você precisa trocar antes de publicar

Edite `src/config/siteConfig.ts`:
- nome da empresa;
- WhatsApp e telefone;
- e-mail;
- endereço, cidade e estado;
- horários;
- redes sociais;
- métricas reais.

Também ajuste `site` em `astro.config.mjs` e o domínio em `public/robots.txt`.

## Conteúdo

- Serviços: `src/data/services.ts`
- Famílias de consoles: `src/data/consoles.ts`
- FAQ: `src/data/faqs.ts`
- Depoimentos: `src/data/testimonials.ts`
- Blog: `src/content/blog/`

## Imagens

Os SVGs em `public/visuals/` funcionam como arte visual própria e leve. Para produção, substitua os visuais de bancada por fotos reais da assistência mantendo `width` e `height` explícitos.
